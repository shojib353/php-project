<?php
include("db_connect.php");
$num=0;

if(isset($_POST["submit"])){
    $name=$_POST["name"];
    $email=$_POST["email"];
    $password=$_POST["psw"]; 
    $repeat_password=$_POST["psw-repeat"];     
    $mobile=$_POST["mobile"];

    if($password!=$repeat_password){
        $error="password not match";
    }
    else{
        $sql= "select * from registration where Email='$email'";
        $result=mysqli_query($con,$sql);
        $num  = mysqli_num_rows($result);
        if($num> 0){  
            
            echo "alrady exist user";
            header("location:signin.php");

        }
        else{
            $sql= "insert into registration(Name,Email,Password,Mobile) values ('$name','$email','$password','$mobile')";
            $sql2= "insert into user_login(Email,Password) values ('$email','$password')";
            
            $result=mysqli_query($con,$sql);
            $result2=mysqli_query($con,$sql2);

            if($result){
                echo "insert success";
            }
        }
    }


}
?>




<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {
  font-family: Arial, Helvetica, sans-serif;
  background-color: whitesmoke;
}

* {
  box-sizing: border-box;
}

/* Add padding to containers */
.container {
  padding: 16px;
  background-color: white;
  width: 50%;
  margin: 0 auto;
}

/* Full-width input fields */
input[type=text], input[type=password] {
  width: 100%;
  padding: 15px;
  margin: 5px 0 22px 0;
  display: inline-block;
  border: none;
  background: #f1f1f1;
}

input[type=text]:focus, input[type=password]:focus {
  background-color: #ddd;
  outline: none;
}

/* Overwrite default styles of hr */
hr {
  border: 1px solid #f1f1f1;
  margin-bottom: 25px;
}

/* Set a style for the submit button */
.registerbtn {
  background-color: #04AA6D;
  color: white;
  padding: 16px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
  opacity: 0.9;
}

.registerbtn:hover {
  opacity: 1;
}

/* Add a blue text color to links */
a {
  color: dodgerblue;
}

/* Set a grey background color and center the text of the "sign in" section */
.signin {
  background-color: #f1f1f1;
  text-align: center;
}
</style>
</head>
<body>

<form action="" method="post">
  <div class="container">
    <h1>Register</h1>
    <p>Please fill in this form to create an account.</p>
    <hr>

    <label for="name"><b>Name</b></label>
    <input type="text" placeholder="Enter Name" name="name" id="name" required>

    <label for="mobile"><b>Mobile</b></label>
    <input type="text" placeholder="Enter Mobile" name="mobile" id="mobile" required>



    <label for="email"><b>Email</b></label>
    <input type="text" placeholder="Enter Email" name="email" id="email" required>

    <label for="psw"><b>Password</b></label>
    <input type="password" placeholder="Enter Password" name="psw" id="psw" required>

    <label for="psw-repeat"><b>Repeat Password</b></label>
    <input type="password" placeholder="Repeat Password" name="psw-repeat" id="psw-repeat" required>
    <span style="color:red"> <?php echo isset($error)?$error:"" ; ?> </span><br>
    <hr>
    

    <button type="submit" name="submit" class="registerbtn">Register</button>
  </div>
  
  <div class="container signin">
    <p>Already have an account? <a href="Signin.php">Sign in</a>.</p>
  </div>
</form>

</body>
</html>
